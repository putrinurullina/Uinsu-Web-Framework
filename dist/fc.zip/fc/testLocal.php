<!DOCTYPE html>
<html>
  <head>
    <title>Web Local Storage</title>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script>
    $(document).ready(function(){
      $('#btnSetData').click(function(){
        localStorage.setItem("nama", "Aditia Darma Nasution");
      });
    });
    </script>
  </head>
  <body>
   <button id='btnSetData'>
     Set Data
    </button>
    <hr/>
    <div>
      Data is :
    </div>
  </body>
</html>