<?php
session_start();
include('../config/connect.php');
date_default_timezone_set("Asia/Jakarta");
$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];
$jlhKarakterPassword = strlen($password);

$ipAddress = $_SERVER['REMOTE_ADDR'];
//user agent
$gadget = $_SERVER['HTTP_USER_AGENT'];
//tanggal & waktu
$tanggal = date("d-m-Y");
$waktu = date("h:i:s");

$bahanIdRegis = "1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
$acakPertamaRegis = str_shuffle($bahanIdRegis);
$idRegis = substr($acakPertamaRegis,3,30);

$acakBahanIdUser = str_shuffle($bahanIdRegis);
$idUser = substr($acakBahanIdUser,3,30);

$passMd5 = md5($password);

//pembuatan kode registrasi 
$bahanKodeRegistrasi = "ZXCVBNMASDFGHJKLQWERTYUIOP";
$acakKodeRegistrasi = str_shuffle($bahanKodeRegistrasi);
$kodeRegistrasi = substr($bahanKodeRegistrasi,0,8);

if($jlhKarakterPassword <= 7){
  echo "Password min. 7 karakter";  
}else{
  //cek apakah email sudah terdaftar
$kCekEmail = $link -> query("SELECT id FROM tbl_user WHERE email='$email';");
$jlhEmailRegis = mysqli_num_rows($kCekEmail);
  if($jlhEmailRegis > 0){
    echo "Email sudah terdaftar";
  }else{   
    //kueri simpan ke database
    //pembuatan id ruang chat
    $bahanIdRuang = "15963245789653251254897";
    $acakBahanIdRuang = str_shuffle($bahanIdRuang);
    $idRuang = substr($acakBahanIdRuang,0,8);
    
    $acakBahanToken = str_shuffle($bahanIdRuang);
    $idTokenChat = substr($acakBahanToken,0,10);
   
     $pesanPembuka = "Terima kasih telah melakukan pendafataran.Silahkan login untuk mengakses aplikasi, Harap lakukan konfirmasi email anda agar dapat melakukan permintaan darah, upload foto profil, serta menerima permintaan darah. "; 
    
    $link -> query("INSERT INTO tbl_registrasi VALUES('','$idRegis','$email','$passMd5','$ipAddress','$tanggal','$waktu','$gadget','$kodeRegistrasi','y');");
    $link -> query("INSERT INTO tbl_user VALUES('','$idUser','$email','user','$passMd5','y');");
    $link -> query("INSERT INTO tbl_user_profile VALUES('','$email','$nama','-','-','-','-','-','-');");
    $link -> query("INSERT INTO tbl_point VALUES('','$email','0','0','y');");
    
    $link -> query("INSERT INTO tbl_ruang_chat VALUES('','$idRuang','admin','1','$email');");
    $link -> query("INSERT INTO tbl_ruang_chat VALUES('','$idRuang','$email','1','admin');");
    $link -> query("INSERT INTO tbl_chat VALUES('','$idTokenChat','admin','$email','$pesanPembuka','$tanggal','$waktu','y','1','$idRuang');");
  }
  
}


?>

<script>
$(document).ready(function(){
  alert("<?=$pesanPembuka; ?>");
  window.location.assign('index.html');
  //$('#divFormDaftar').html("<div style='text-align:center;>Terima kasih telah melakukan pendaftaran di apheresisApps. Silahkan <a href='index.html'>Login</a> untuk masuk ke akun anda.</div>");
});
</script>


