<?php
session_start();
include('../config/connect.php');


$emailData = $_GET['email'];
$passwordData = $_GET['password'];
$md5Pass = md5($passwordData);

$qLogin = $link -> query("SELECT * FROM tbl_user WHERE username='$emailData' AND password='$md5Pass' LIMIT 0,1");
$fLogin = $qLogin -> num_rows;

$bahanIdLogin = "1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
$acakPertama = str_shuffle($bahanIdLogin);
$idLogin = substr($acakPertama,3,30);
//idRegistrasi
//ip address
$ipAddress = $_SERVER['REMOTE_ADDR'];
//user agent
$gadget = $_SERVER['HTTP_USER_AGENT'];
//tanggal & waktu
$tanggal = date("d-m-Y");
$waktu = date("h:i:s");
//kirim ke log login
//$kSisipData = $link -> query("INSERT INTO tbl_log_login VALUES('','$idLogin','$emailData','$ipAddress','$gadget','$tanggal','$waktu','y');");  
 class Emp {
      public $email = "";
      public $password  = "";
      public $type = "";
      public $statusLogin = "";
	 		public $token = "";
 }
	
   $e = new Emp();
   $e -> email = $emailData;
   $e -> password = $md5Pass;
   $e -> statusLogin = $fLogin;
   $e -> type = "User";
	 $e -> token = "db0bc3a9b77e7eff8490bcf2a3d800fe";
	 $e -> ipAddress = $ipAddress;
   $e -> waktu = $tanggal."-".$waktu;
   echo json_encode($e);
?>
