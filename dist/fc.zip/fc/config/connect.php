<?php
$link = new mysqli('localhost','root','','dbs_fahri');
?>