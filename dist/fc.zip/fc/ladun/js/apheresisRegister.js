$(document).ready(function(){
  
  var angka1 =  Math.floor((Math.random() * 11) + 1);
  var angka2 = Math.floor((Math.random() * 11) + 1);
      
  $('#divCapcha').html("<i>Please answer : <b> "+angka1+" + "+angka2+" = ");
  $('#btnDaftar').click(function(){
    var nama = $('#txtNama').val();
    var email = $('#txtEmail').val();
    var password = $('#txtPassword').val();
    var jawaban = $('#txtJawaban').val();
    var hasilCapcha = angka1 + angka2;
    console.log(hasilCapcha);
    
    
    
    
    if(nama===""){
      $('#txtNama').focus();
    }else if(email===""){
      $('#txtEmail').focus();
    }else if(password===""){
      $('#txtPassword').focus();
    }else if(jawaban===""){
         $('#txtJawaban').focus();   
    }else{      
      if(hasilCapcha == jawaban){
        $('#statLogin').html("Submit data..");    
        
        $('#statLogin').load('jsonData/registerSystem.php',{'nama':nama,'email':email,'password':password});     
      }else{
       $('#statLogin').html("Jawaban capcha salah!!");  
      }     
      
    }
    
  });
});