<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];
$namaLengkap = $_POST['namaLengkap'];
$tanggalLahir = $_POST['tanggalLahir'];
$jenisKelamin = $_POST['jenisKelamin'];
$alamat = $_POST['alamat'];
$golonganDarah = $_POST['golonganDarah'];
$hp = $_POST['hp'];
//perintah update
$kUpdate = $link -> query("UPDATE tbl_user_profile SET nama_lengkap='$namaLengkap', tanggal_lahir='$tanggalLahir', alamat_lengkap='$alamat', bio='-', jenis_kelamin='$jenisKelamin', no_hp='$hp', golongan_darah='$golonganDarah' WHERE email='$emailId'");
?>
<script>
$(document).ready(function(){
  $('#btnKembali').click(function(){
    var loading = "<div class='progress'><div class='indeterminate'></div></div>";
            $('#judulApps').html("Profil - Apheresis Apps");
            $('#divUtama').html(loading);
            $('#divUtama').load('profile.php');
  });
});
</script>
<div>
Sukses mengupdate data ...<br/>
<a class="waves-effect waves-light white red-text btn" id="btnKembali">Kembali ke profil</a>
</div>