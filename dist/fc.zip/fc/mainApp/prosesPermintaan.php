<?php
session_start();
include('../config/connect.php');
$namaRapesien = $_POST['namaRapesien'];
$diagnosa = $_POST['diagnosa'];
$rumahSakit = $_POST['rumahSakit'];
$pesan = $_POST['pesan'];
$emailId = $_SESSION['emailIdSession'];
$tanggal = date("d-m-Y");
$waktu = date("h:i:s");
$bahanId = "123456789123456789123456789123456789";
$acakBahan = str_shuffle($bahanId);
$idPermintaan = substr($acakBahan,0,40);
//perintah kirim ke database 
$qSimpanPermintaan = $link -> query("INSERT INTO tbl_permintaan_darah VALUES('','$idPermintaan','$emailId','$pesan','$tanggal','$waktu','-','y','$namaRapesien','$diagnosa','$rumahSakit');");
?>
<script>
$(document).ready(function(){
  $('#divStatusPermintaan').load('dataStatusPermintaanDarah.php');
});
</script>
<div class="card-content white-text">
<div style="text-align:justify;"> Terima kasih. Permintaan donor telah disimpan. Admin Apheresis akan segera memproses permintaan anda &amp; menyampaikan kesemua calon pendonor yang sesuai dengan kriteria<br/>
  Berikut ini adalah data permintaan yang telah ada kirim </div></br>
Nama : <b><?=$namaRapesien; ?></b><br/>
Diagnosa:  <b><?=$diagnosa; ?></b><br/>
Rumah Sakit : <b><?=$rumahSakit; ?></b><br/>
Diagnosa : <b><?=$diagnosa; ?></b>
</div>