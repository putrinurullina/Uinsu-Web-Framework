<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];
//kueri menampilkan data status permintaan darah
$kPermintaanDarah = $link -> query("SELECT * FROM tbl_permintaan_darah WHERE email='$emailId' ORDER BY id DESC LIMIT 0,5;");


?>
<table class="striped">
        <thead>
          <tr>
              <th>ID Permintaan</th>
              <th>Tanggal</th>
              <th>Status</th>
          </tr>
        </thead>

        <tbody>
          <?php
          while($fReq = $kPermintaanDarah -> fetch_array()){
            $nama = $fReq['nama'];
            $diagnosa = $fReq['diagnosa'];
            $rumahSakit = $fReq['rumah_sakit'];
            $pesan = $fReq['pesan'];
            $tanggal = $fReq['tanggal'];
            $waktu = $fReq['jam'];
            $idPermintaan = $fReq['id_permintaan'];
            //cari status approve di tabel approve
            $kApprove = $link -> query("SELECT id FROM tbl_approve_request_darah WHERE id_request='$idPermintaan' LIMIT 0,1;");
            $diApprove = mysqli_num_rows($kApprove);
            $statusApprove = "";
            $warna_text = "";
            $idShort = substr($idPermintaan,4,5);
            if($diApprove <= 0){
              $statusApprove = "Sudah di approve";
              $warna_text = "green";
            }else{
              $statusApprove = "Pending";
              $warna_text = "black";
            }
            echo "<tr>
            <td> <i class=\"material-icons\">accessible</i> <b>$nama</b><br/>
              <i class=\"material-icons\">receipt</i><b> $diagnosa</b><br/>
              <i class=\"material-icons\">room</i><b> $rumahSakit</b><br/>
               \"$pesan\"</td>
            <td>$tanggal<br/><b>($idShort)</b></td>
            <td class=\"$warna_text-text\">$statusApprove</td>
          </tr>";
            
          }
          
          ?>
        </tbody>
  <i>Permintaan darah yang tidak valid akan dihapus oleh admin</i>
      </table>
            