<?php
session_start();
include('../config/connect.php');
$email = $_POST['emailPost'];
//cek apakah email sudah terdaftar
$kCekEmail = $link -> query("SELECT id FROM tbl_user WHERE email='$email' LIMIT 0,1;");
$jlhAkun = mysqli_num_rows($kCekEmail);
$keBrowser = "";

if($jlhAkun <= 0){
  $pass = md5($_POST['passwordPost']);
$bahanIdRegistrasi = "1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
$acakPertama = str_shuffle($bahanIdRegistrasi);
//idRegistrasi
$ambilSub = substr($acakPertama, 4, 40);
//ip address
$ipAddress = $_SERVER['REMOTE_ADDR'];

//user agent
$gadget = $_SERVER['HTTP_USER_AGENT'];
//tanggal & waktu
$tanggal = date("d-m-Y");
$waktu = date("h:i:s");
//kodeRegistrasi
$kodeRegistrasiBahan = "12345678909876543219283746565748391";
$acakKodeRegistrasi = str_shuffle($kodeRegistrasiBahan);
$kodeRegistrasi = substr($acakKodeRegistrasi, 5, 10);
$selanjutnya = "";
$qSisip = $link -> query("INSERT INTO tbl_registrasi VALUES('','$ambilSub','$email','$pass','$ipAddress','$tanggal','$waktu','$gadget','$kodeRegistrasi','n');");
$_SESSION['emailIdSession'] = $email;
$subjekEmail = "Informasi Registrasi";
$pesan = "Anda telah melakukan pendaftaran di Aplikasi Apheresis Medan. Silahkan <a href='http://1gateactivateaccount.nadha.net/apheresisMedan/activateAccount.php?id=$ambilSub' target='new'>AKTIVASI AKUN</a><br/>
Kami mengucapkan terima kasih sebanyak banyaknya karena anda telah bergabung di aplikasi Apheresis Medan ini. Mari bantu mereka yang membutuhkan pertolongan kita. <br/>
Hormat Kami, <br/>
<br/>
Apheresis Medan.
";
$header = "From:registrasi@apheresis.nadha.net \r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html\r\n";
mail ($email,$subjekEmail,$pesan,$header);
  $keBrowser = "window.location.assign(\"selesaiPendaftaran.php\");";

}else{
  $keBrowser = "$('#statDaftar').html('Email sudah terdaftar!!');";
}
?>
<script>
$(document).ready(function(){
  
  console.log("Jumlah email = <?=$jlhAkun; ?>");
  <?=$keBrowser; ?>;

});
</script>

