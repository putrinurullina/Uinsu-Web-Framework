<script>
$(document).ready(function(){
  $('.collapsible').collapsible();
});
</script>
<div class="row">
  <center>
   <img class="responsive-img" style="width: 90px;margin-top:12px;" src="../asset/img/logo.png" alt="logo apheresis"/><br/>
    <h4>Apheresis</h4>
    <h5>Pendonor Sukarela</h5>
  </center>
  <div style="text-align:justify;padding-top:12px;" class="container">
    <p>
  Terima Kasih Telah Mendownload Aplikasi Apheresis.
Selamat datang di aplikasi apheresis pendonor sukarela.
Aplikasi Apheresis merupakan aplikasi yang menghubungkan
pasien yang membutuhkan darah whole blood dan Trombosit
dengan pendonor yang sukarela mendonorkan darahnya.
  </p><br/>
  </div>
  
</div>
<ul class="collapsible" data-collapsible="accordion">
    <li>
      <div class="collapsible-header"><i class="material-icons">control_point</i>Apa beda darah Whole Blood dengan Trombosit?</div>
      <div class="collapsible-body" style='text-align:justify;'><span >Whole Blood adalah jenis darah tranfusi dengan komponen lengkap, yaitu memiliki plasma dan semua sel darah serta komponen darah. 
Biasanya tranfusi whole blood digunakan untuk pasien yang kekurangan semua komponen darah.<br/>
Trombosit adalah salah satu bagian dari komponen dalam darah manusia. 
Trombosit mengandung sejumlah senyawa dan butiran yang bekerja untuk 
membekukan darah ketika terjadi cedera.
berberapa penyakit yang membuat trombosit menjadi rendah, mungkin yang paling poluler adalah Demam Berdarah dan Kangker.</span></div>
    </li>
    <li>
      <div class="collapsible-header"><i class="material-icons">control_point</i>Kebijakan Privasi Aplikasi</div>
      <div class="collapsible-body" style='text-align:justify;'><span>Bagi User yang ingin mencari darah untuk pasien yang membutuhkan darah
agar menulis di fitur beranda, kemudian akan menunggu persetujuan dari admin.
dan user silahkan chat/pesan admin pada fitur obrolan, agar post user akan disetujui admin.
hal ini dilakukan agar mengetahui permintaan darah benar-benar valid dan diketahui admin.
<br/>
Bagi pendonor, aplikasi ini mengkhususkan menghubungkan
pasien yang membutuhkan darah whole blood dan Trombosit
dengan pendonor yang sukarela mendonorkan darahnya.  
yang ingin mendonorkan darahnya haruslah sukarela dan tidak
mengharapkan imbalan apapun ke keluarga pasien.
</span></div>
    </li>
  
  <li>
      <div class="collapsible-header"><i class="material-icons">control_point</i>Apa itu point Aphresis?</div>
      <div class="collapsible-body" style='text-align:justify;'><span>
        Point Aphresis adalah point yang diberikan kepada pendonor yang telah memberikan bantuan donor darah kepada
        rapesien. Bentuk penghargaan akan disampaikan oleh admin melalui kotak pesan ataupun kontak lain dari pendonor
</span></div>
    </li>
  
  
    
  </ul>