<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];
$idRuang = $_POST['idRuang'];
//cari data chat user
$kDataChat = $link -> query("SELECT * FROM tbl_chat WHERE id_ruang='$idRuang';");
//cari chat dengan 
$kCariChatDenganSiapa = $link -> query("SELECT kepada FROM tbl_ruang_chat WHERE id_ruang='$idRuang' AND inisiator='$emailId';");
$fChatDengan = $kCariChatDenganSiapa -> fetch_array();
$kepada = $fChatDengan['kepada'];
?>
<script>
$(document).ready(function(){
  $('#btnKirim').click(function(){
    var pesan = $('#textarea1').val();
    var emailPenerima = '<?=$kepada;?>';
    var idRuang = '<?=$idRuang; ?>';
    
    if(pesan==""){
      $('#textarea1').focus();
    }else{
      $('#divStatPesan').html('<small>Mengirim pesan...</small>');
      $.post('proKirimChat.php',{'pesan':pesan,'emailPenerima':emailPenerima,'idRuang':idRuang},function(){
          //$('#containerUtama').load('settingCabang.php');
          $('#divStatPesan').html('');
          $('#divUtama').load('ruangChatPrivat.php',{'idRuang':idRuang});
        });
    }
    
  });
});
</script>
<div class="container">
  <div class="row">
    <div class="card red" id="divRequest">
            <div class="card-content white-text" >
              <span class="card-title">Chat dengan <?=$kepada; ?></span>     
              
              <?php
              while($fChat = $kDataChat -> fetch_array()){
                $chat = $fChat['chat'];
                $emailPengirim = $fChat['email_pengirim'];
                $printChat = "";
                
                if($emailPengirim==$emailId){
                  $printChat = "<td style=''> $chat</td><td style='width:20px;'> <i class=\"material-icons\">account_circle</i></td>";
                }else{
                  $printChat = "<td style='width:20px;'> <i class=\"material-icons\">account_circle</i></td><td style=''>$chat</td>";
                }
                
                
                
                echo "<div style='background-color:#ffcdd2;text-align:left;margin-bottom:5px;color:#424242;'>
                 <table>
            <tr>
            $printChat
            </tr>
          </table>
              </div>";
              }
              
              ?>  
              <hr/>           
              
              <div class="row white" style='margin:1px;'>
   
      <div class="row" style='padding-top:12px;padding-left:12px;padding-right:12px;'>
        <div class="input-field col s12 black-text">
          <textarea id="textarea1" class="materialize-textarea"></textarea>
          <label for="textarea1">Pesan</label>
          <div id='divStatPesan'></div>
        </div>
        <button class='btn' style='margin-left:12px;' id='btnKirim'>Kirim</button>
      </div>
    
  </div>
              
              
              
    </div>
  </div>
  
</div>
</div>