<?php
session_start();
include('../config/connect.php');

//$emailDariGet = $_GET['emailGet'];
//kueri tampil daftar permintaan donor
$kDaftarPermintaan = $link -> query("SELECT * FROM tbl_approve_request_darah order by id desc LIMIT 0, 20");
$kJumlahUser = $link -> query("SELECT id FROM tbl_user");
$jlhUser = mysqli_num_rows($kJumlahUser);
//kueri buat persentasi 
$persenAwal = 10;

?>

<script type="text/javascript">
	$(document).ready(function(){
		//simpan data dom ke variabel
		$('.modal').modal();
		$('.modal').modal({dismissible: false});
		var btnInfo = $('#btnInfo');
		$('.carousel').carousel();
		$('.carousel.carousel-slider').carousel({fullWidth: true});
		
		btnInfo.click(function(){
			console.log("Tombol info di klik!");
		});
		
		$('.btnCall').click(function(){
           var mentahId = $(this).attr('id');
					 var pesanCallModal = "Anda dapat langsung menghungi kontak rapesien : " + mentahId;
					 $('#divPesanModal').html(pesanCallModal);
					 $('#modalCall').modal('open');
					 console.log(mentahId);				
     });
		
		$('.btnChat').click(function(){
			$('#divUtama').html("<div class='progress'><div class='indeterminate'></div></div>");
			$('#divUtama').load('ruangChat.php');
		});
    
    $('#nextPage').click(function(){
      alert("Tombol selanjutnya di klik..");
    });
		
	});
</script>
<div class="row">
	<div col="col s12" style="padding:10px;">
	
	<div id="loading">		</div>
 <div class="carousel carousel-slider center" data-indicators="true">
    <div class="carousel-fixed-item center">
      <div class="kotakCaption" id="fSlide1">
         <h5>Galeri Apheresis</h5>
      <p class=" text-darken-3">Foto kegiatan Apheresis Medan</p>
      </div>
    </div>
    <div class="carousel-item  white-text slideBerita" href="#!" style="background-image: url('../asset/img/news/slide_1.jpg');" >     
    </div>
    
    <div class="carousel-item  white-text slideBerita" href="#!" style="background-image: url('../asset/img/news/slide_2.jpg');">     
    </div>
    
    <div class="carousel-item  white-text slideBerita" href="#!" style="background-image: url('../asset/img/news/slide_3.jpg');">     
    </div>
   
  </div>
    <div style='text-align:center;'><h4 class=red-text>
      Statistik Pemilih
      </h4>
      
    </div>
    <div class='row'>
      <div class="col s6 center">
        <h1><?=$jlhUser; ?></h1>
        Pendonor Aktif
      </div>
       <div class="col s6 center">
         <h1>0</h1>
        Permintaan Darah
      </div>
    </div>
    
    
    <div class='row'>
      <div class="col s6 center">
        <h1>0</h1>
        Permintaan Terpenuhi
      </div>
       <div class="col s6 center">
         <h1>0%</h1>
        Rasio Aktivitas
      </div>
    </div>
    
    
		<hr/>
<br/>
	<div class="center red-text">
		Informasi permintaan darah
		</div>
		<div class="collection">
    <div class="collection-item">
			<table class="bordered">
				<?php
				
				while($fApp = $kDaftarPermintaan -> fetch_array()){
					$idRequest = $fApp['id_request'];
					$kAmbilDariPermintaan = $link -> query("SELECT * FROM tbl_permintaan_darah WHERE id_permintaan='$idRequest' LIMIT 0,1;");
					$fPermintaan = $kAmbilDariPermintaan -> fetch_array();
					$pesan = $fPermintaan['pesan'];
					$nama = $fPermintaan['nama'];
					$rumahSakit = $fPermintaan['rumah_sakit'];
					$diagnosa = $fPermintaan['diagnosa'];
					$email = $fPermintaan['email'];
					//cari hp dari email
					$kCariHp = $link -> query("SELECT no_hp FROM tbl_user_profile WHERE email='$email' LIMIT 0,1;");
					$fHp = $kCariHp -> fetch_array();
					
					$hp = $fHp['no_hp'];
					echo "<tr>
					<td><img class=\"circle\" src=\"../asset/img/user/default.png\" style=\"width:50px;\"></td>
					<td class=\"left-align\"><b> $nama</b><br/>
					 <blockquote>
						<small>
							\"$pesan\" <br/> Diagnosa : <i>$diagnosa</i>
							<br/> Rumah Sakit : <i>$rumahSakit</i>
						</small>
						</blockquote>
						
						
						<a class=\"btn-floating btn waves-effect waves-light red\"><i class=\"material-icons\">info</i></a>&nbsp;
						<a class=\"btn-floating btn waves-effect waves-light red btnCall\" id='$hp'><i class=\"material-icons\">call</i></a>&nbsp;
						<a class=\"btn-floating btn waves-effect waves-light red btnChat\"><i class=\"material-icons\">chat_bubble</i></a>
						<a class=\"btn-floating btn waves-effect waves-light red btnChat\"><i class=\"material-icons\">contact_mail</i></a>
					</td>
					
				</tr>
				";
				}
				?>
				
			</table>
		</div>
			
  </div>
		
	<div>
    <div class="progress white">
      <div class="determinate red" style="width: 100%"></div>
  </div>
    <ul class="pagination">     
       <li class="">
         <i class="material-icons">chevron_left</i>
         </li>
       <li class="" id='nextPage'><a href="#!"><i class="material-icons">chevron_right</i></a></li>
    </ul>
    </div>
	</div>
</div>

<div id="modalCall" class="modal">
    <div class="modal-content">
       <h3>
				 Kontak Rapesien
			</h3>
     <div id="divPesanModal">
			 
			</div>
			<br/>
			<div class="chip modal-close">
    Akan saya hubungi 
    
  </div>
			</a>
    </div>
    </div>
			</div>   

