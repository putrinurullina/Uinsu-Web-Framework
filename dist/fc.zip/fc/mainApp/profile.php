<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];

//kueri tampilkan profil 
$kTampilProfile = $link -> query("SELECT * FROM tbl_user_profile WHERE email='$emailId' LIMIT 0,1;"); 
$fProfile = $kTampilProfile -> fetch_array();
$namaLengkap = $fProfile['nama_lengkap'];
$tanggalLahir = $fProfile['tanggal_lahir'];
$jenisKelamin = $fProfile['jenis_kelamin'];
$alamat = $fProfile['alamat_lengkap'];
$golDarah = $fProfile['golongan_darah'];
$noHp = $fProfile['no_hp'];
//cari total point berdasarkan email
$kTotalPoint = $link -> query("SELECT * FROM tbl_point WHERE id_user='$emailId';");
$fTotalPoint = $kTotalPoint -> fetch_array();
$totalPoint = $fTotalPoint['point'];

if($jenisKelamin=="l"){
  $capJk = "Laki-Laki";
}elseif($jenisKelamin=="p"){
  $capJk = "Perempuan";
}else{
  $capJk = "-";
}

?>
<script>
$(document).ready(function(){
  var btnUbahProfile = $('#tblUbahProfile');
  btnUbahProfile.click(function(){
    var email = "<?=$emailId;?>";
    $("#divProfile").load('formEditProfile.php');
    $(this).hide();
  });
});
</script>
<div class="container">
  <div class="row">
        <div class="col s12 m6">
          <div class="card red" id="divRequest">
            <div class="card-content white-text center-align">
              <span class="card-title">Profil Pengguna </span>
              <img src="../asset/img/user/default.png" alt="{{SQL Connection Error}}" style='width:200px;' class="circle responsive-img">
              <hr/>
              <div id="divProfile">
                <table>
                      <tr>
                      <td>Nama</td><td><?=$namaLengkap; ?></td>
                      </tr>
                      <tr>
                      <td>Email</td><td><?=$emailId; ?></td>
                      </tr>
                      <tr>
                      <td>Tanggal Lahir</td><td><?=$tanggalLahir; ?></td>
                      </tr>
                      <tr>
                      <td>Jenis Kelamin</td><td><?=$capJk; ?></td>
                      </tr>
                      <tr>
                      <td>Alamat</td><td><?=$alamat; ?></td>
                      </tr>
                      <tr>
                      <td>Gol. Darah</td><td><?=$golDarah; ?></td>
                      </tr>
                      <tr>
                      <td>No. Hp</td><td><?=$noHp; ?></td>
                      </tr>
                      <tr>
                      <td>Total Point</td><td><?=$totalPoint; ?> Point</td>
                      </tr>
                      
              </table>
          
              </div>
                    

         
            </div>
            <div class="card-action center-align">
             <a class="waves-effect waves-light btn" id="tblUbahProfile"><i class="material-icons right">cloud</i>Ubah Profil</a>
              
            </div>
          </div>
        </div>
    <hr/>
    
    <div id="divStatusPermintaan">
      
    </div>
    
      </div>
</div>