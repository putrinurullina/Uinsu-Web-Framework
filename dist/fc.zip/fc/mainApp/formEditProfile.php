<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];
//cari informasi dasar 
$kProfile = $link -> query("SELECT * FROM tbl_user_profile WHERE email='$emailId';");
$fProfile = $kProfile -> fetch_array();
$namaLengkap = $fProfile['nama_lengkap'];
$tanggalLahir = $fProfile['tanggal_lahir'];
$alamat = $fProfile['alamat_lengkap'];
$golDarah = $fProfile['golongan_darah'];
$noHp = $fProfile['no_hp'];
?>
<script>
$(document).ready(function() {
    $('select').material_select();
    $('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false // Close upon selecting a date,
  });
  $('#tblSimpanProfil').click(function(){
    var namaLengkap = $('#txtNama').val();
    var tanggalLahir = $('#txtTanggalLahir').val();
    var jenisKelamin = $('#txtJenisKelamin').val();
    var alamat = $('#txtAlamat').val();
    var golonganDarah = $('#txtGologanDarah').val();
    var hp = $('#txtNomorHp').val();
    $('#divStatusSimpan').load('prosesSimpanProfile.php',{'namaLengkap':namaLengkap,'tanggalLahir':tanggalLahir,'alamat':alamat,'jenisKelamin':jenisKelamin,'golonganDarah':golonganDarah,'hp':hp});
    $('#divFormEdit').hide();
  });
});
  
</script>
<div id="divStatusSimpan"></div>
<div id="divFormEdit">
  

Edit Profile
<table>
                      <tr>
                      <td>Nama</td><td><input id="txtNama" type="text" class="validate" value="<?=$namaLengkap; ?>"></td>
                      </tr>
                      <tr>
                      <td>Email</td><td><?=$emailId; ?></td>
                      </tr>
                      <tr>
                      <td>Tanggal Lahir</td><td><input id="txtTanggalLahir" type="text" class="datepicker" value="<?=$tanggalLahir; ?>"></td>
                      </tr>
                       <tr>
                      <td>Jenis Kelamin</td><td>
                      <select id="txtJenisKelamin">
                        <option value="l">Laki Laki</option>
                        <option value="p">Perempuan</option> 
                        
                      </select>
                        
                      </td>
                      </tr>
                      <tr>
                      <td>Alamat</td><td><input id="txtAlamat" type="text" class="validate" value="<?=$alamat; ?>"></td>
                      </tr>
                      <tr>
                      <td>Gol. Darah</td><td>
                      <select id="txtGologanDarah">
                        <option value="A Plus">A +</option>
                        <option value="A Minus">A -</option> 
                        <option value="B Plus">B +</option>
                        <option value="B Minus">B -</option>
                        <option value="AB Plus">AB +</option>
                        <option value="AB Minus">AB -</option>
                        <option value="O Plus">O +</option>
                        <option value="O Minus">O -</option>
                      </select>
                        
                      </td>
                      </tr>
                      <tr>
                      <td>No. Hp</td><td><input id="txtNomorHp" type="text" class="validate" value="<?=$noHp; ?>"></td>
                      </tr>
                      
              </table>
              <a class="waves-effect waves-light btn" id="tblSimpanProfil"><i class="material-icons right">cloud</i>Simpan</a><br/>
              <div class="left">
                <p>
                  Panduan untuk mengupdate foto profil </p>
                 <ul>
                   <li>Ukuran foto tidak melebihi 2 Mb</li>
                   <li>Karena belum tersedia fasilitas cropping, diharapkan foto berdimensi persegi (kotak)</li>
                </ul>
                
  </div>
          </div>
