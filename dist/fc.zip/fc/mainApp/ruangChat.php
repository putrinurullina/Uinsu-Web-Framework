<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];
//cari data chat user
$kDataChat = $link -> query("SELECT * FROM tbl_ruang_chat WHERE inisiator='$emailId';");

?>

<script>
$(document).ready(function(){
  
  var delayChat = 3000;
  $('.btnChatRoom').click(function(){
    var idRuangChat = $(this).attr("id");
    $('#divUtama').load('ruangChatPrivat.php',{'idRuang':idRuangChat});
    console.log("Siap masuk ke chat room : + " + idRuangChat);
  });
});
</script>
<div class="container">
  <div class="row">
    <div class="card red" id="divRequest">
            <div class="card-content white-text left-align">
              <span class="card-title">Ruang Obrolan </span>
    <a class="waves-effect waves-light btn"><i class="material-icons left">mode_comment</i>Buat pesan</a>
              
              <ul class="collection black-text">
                
                <?php
                while($fChat = $kDataChat -> fetch_array()){
                  $userPenerima = $fChat['kepada'];
                  $idRuang = $fChat['id_ruang'];
                  //cari nama lenkap
                  $kCariNamaLengkap = $link -> query("SELECT * FROM tbl_user_profile WHERE email='$userPenerima' LIMIT 0,1;");
                  $fNama = $kCariNamaLengkap -> fetch_array();
                  $namaLengkap = $fNama['nama_lengkap'];
                  $namaPenerima = "";
                  
                  if($namaLengkap == ""){
                    $namaLengkap = "Administrator";
                  }else{
                    
                  }
                 
                  //isi chat terakhir
                  $kChatTerakhir = $link -> query("SELECT * FROM tbl_chat WHERE id_ruang='$idRuang' ORDER BY id DESC LIMIT 0, 1;");
                  $fChatAkhir = $kChatTerakhir -> fetch_array();
                  $chatAkhir = $fChatAkhir['chat'];
                  $chatAkhir = substr($chatAkhir,0,25);
                  $jlhChatTerakhir = mysqli_num_rows($kChatTerakhir);
                  $tanggal = $fChatAkhir['tanggal']; 
                  echo "<li class=\"collection-item avatar btnChatRoom\" id='$idRuang'>
      <img src=\"../asset/img/user/default.png\" alt=\"\" class=\"circle\">
      <span class=\"title\">$namaLengkap</span>
      <p>
         <small>$chatAkhir ..</small>
      </p>
      <a href=\"#!\" class=\"secondary-content\"><i class=\"material-icons\">done_all</i></a>
    </li>"; 
                }
                
                ?>
   
  </ul>
              
              
      </div>
    </div>
  </div>
  
</div>