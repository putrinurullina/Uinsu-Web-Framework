<?php
session_start();
include('../config/connect.php');
$emailId = $_SESSION['emailIdSession'];
$pesan = $_POST['pesan'];
$emailPenerima = $_POST['emailPenerima'];
$idRuang = $_POST['idRuang'];
//pembuatan token chat
$bahanTokenChat = "12345678987654321";
$acakToken = str_shuffle($bahanTokenChat);
$tokenChat = substr($acakToken,0,10);
//tanggal & waktu
$tanggal = date("d-m-Y");
$waktu = date("h:i:s");
//kueri simpan ke database
$link -> query("INSERT INTO tbl_chat VALUES('','$tokenChat','$emailId','$emailPenerima','$pesan','$tanggal','$waktu','y','1','$idRuang');");

?>