<?php
session_start();
include('../config/connect.php');

?>
<script>
$(document).ready(function(){
  $('#divStatusPermintaan').load('dataStatusPermintaanDarah.php');
  $('#btnSubmitPermintaan').click(function(){
    //alert("Data siap di submit!!");
    var pesan = $('#txtPesan').val();
    var namaRapesien = $('#txtNamaRapesien').val();
    var diagnosa = $('#txtDiagnosa').val();
    var rumahSakit = $('#txtRumahSakit').val();
    
    if(namaRapesien==""){
      $('#txtNamaRapesien').focus();
    }else if(diagnosa==""){
      $('#txtDiagnosa').focus();
    }else if(rumahSakit==""){
      $('#txtRumahSakit').focus();
    }else{
      console.log("Data siap dikirimkan ke server ... ");
      $('#divRequest').html("<div class='center'><div class='progress'><div class='indeterminate'></div></div><br/><p class='white-text'>Sedang memproses permintaan</p></div>");
      $('#divRequest').load('prosesPermintaan.php',{'namaRapesien':namaRapesien,'diagnosa':diagnosa,'rumahSakit':rumahSakit,'pesan':pesan});
      
    }
    
    
  });
});
</script>
<div class="containter">
  <div class="row">
        <div class="col s12 m6">
          <div class="card red" id="divRequest">
            <div class="card-content white-text">
              <span class="card-title">Request Donor </span>
              
          <input placeholder="Nama Rapesien" id="txtNamaRapesien" type="text" class="validate">
          <input placeholder="Diagnosa" id="txtDiagnosa" type="text" class="validate">
               <input placeholder="Rumah Sakit" id="txtRumahSakit" type="text" class="validate">
          <textarea id="txtPesan" class="materialize-textarea" placeholder="Masukkan pesan untuk publikasi. Pesan ini akan terlihat di dasbor calon pendonor"></textarea>
         
            </div>
            <div class="card-action">
              <a href="#" class="btn white red-text" id="btnSubmitPermintaan">Kirim permintaan</a>
              
            </div>
          </div>
        </div>
    <hr/>
    <p class="center-align">
      Status permintaan darah
    </p>
    <div id="divStatusPermintaan">
      
    </div>
    
      </div>
</div>