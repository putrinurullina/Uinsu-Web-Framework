<!DOCTYPE html>
<html>
  <head>
    <title>Web Local Storage</title>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script>
    $(document).ready(function(){
      var namaLokal = localStorage.nama;
      if(namaLokal==""){
        
      }
      $('#divResult').html(namaLokal);
    });
    </script>
  </head>
  <body>
   
    <hr/>
    <div id="divResult">
      Data is :
    </div>
  </body>
</html>