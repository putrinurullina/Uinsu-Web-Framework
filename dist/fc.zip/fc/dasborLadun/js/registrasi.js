$(document).ready(function(){
  //inisialisasi variabel dan DOM
  console.log("Halaman berhasil di load");
  $('.modal').modal({dismissible: false});
  $('select').material_select();
  var btnDaftar = $('#btnDaftar');
  $('#txtEmail').focus();
  var dataClient = navigator.userAgent;
  console.log("Client sedang mengakses di : " + dataClient);
  //event tombol submit
  function toLog(idPesan){
    console.log("Message from engine : " + idPesan);
  }
  
  btnDaftar.click(function(){
    var inputEmail = $('#txtEmail').val();
    var inputPassword = $('#txtPassword').val();
    //periksa form email dan password
    if(inputEmail==""){
      $('#txtEmail').focus();
      toLog("Email belum terisi...");
    }else if(inputPassword==""){
      $('#txtPassword').focus();
      toLog("Password belum terisi...");
    }else{
      toLog("Engine siap memproses pendaftaran ... ");
      $('#statDaftar').html("<div class=\"progress\"><div class=\"indeterminate\"></div></div>");
      $('#toProses').load('prosesDaftar.php',{'emailPost':inputEmail,'passwordPost':inputPassword});
      
    }

  });
  
 
  
  $('#btnTentang').click(function(){
    
  });
  
});