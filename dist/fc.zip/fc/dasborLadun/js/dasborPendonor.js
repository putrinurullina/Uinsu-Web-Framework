$(document).ready(function(){
          $('.materialboxed').materialbox();
          $('.button-collapse').sideNav();
          $('select').material_select();
         

  
          console.log("Halaman berhasil di load");
          $('#divUtama').html("<div class='progress'><div class='indeterminate'></div></div>");
          $('#divUtama').load('berandaPendonor.php');
          $('#judulApps').html("Fahri Iswahyudi Center - Beranda");
          //inisialisasi tombol ke variabel 
          var tblHomeSn = $('#homeSideNav');
          var tblProfile = $('#profileSideNav');
          var tblRequestDonor = $('#requestDonorSideNav');
          var tblRekapDonor = $('#rekapDonorSideNav');
          var tblKotakSiaran = $('#kotakSiaranSideNav');
          var tblObrolan = $('#obrolanSideNav');
          var tblLogOut = $('#LogOutSideNav');
          var btnInfoFloat = $('#btnInfoFloat');
          var btnDasborFloat = $('#btnDasborFloat');
  
  
          function eventTombol(namaTombol){
             console.log("Tombol "+ namaTombol +" di klik!!");
          }
          //event tombol home side di klik
          tblHomeSn.click(function(){
            eventTombol("Dasbor");
            var loading = "<div class='progress'><div class='indeterminate'></div></div>";
            $('#loading').html(loading);
            $('#judulApps').html("Fahri Iswahyudi Center - Beranda");
            $('#divUtama').load('berandaPendonor.php');
            $('#loading').html("");
            $('.button-collapse').sideNav('hide');
          });
          //event tombol profile side di klik
          tblProfile.click(function(){
            eventTombol("Profile");
            var loading = "<div class='progress'><div class='indeterminate'></div></div>";
            $('#judulApps').html("Profil - Apheresis Apps");
            $('#divUtama').html(loading);
            $('#divUtama').load('profile.php');
            $('.button-collapse').sideNav('hide');

          });
  
      tblRekapDonor.click(function(){
        $('#divUtama').html("<div class='progress'><div class='indeterminate'></div></div>");
        $('#judulApps').html("Rekap Donor - Apheresis Apps");
			  $('#divUtama').load('rekapDonor.php');
         $('.button-collapse').sideNav('hide');
      });
  
  tblKotakSiaran.click(function(){
        $('#divUtama').html("<div class='progress'><div class='indeterminate'></div></div>");
        $('#judulApps').html("Kotak Siaran - Apheresis Apps");
			  $('#divUtama').load('kotakSiaran.php');
         $('.button-collapse').sideNav('hide');
      });
  
  
      tblObrolan.click(function(){
        $('#divUtama').html("<div class='progress'><div class='indeterminate'></div></div>");
        $('#judulApps').html("Ruang Obrolan - Apheresis Apps");
			  $('#divUtama').load('ruangChat.php');
         $('.button-collapse').sideNav('hide');
      });
          
        tblLogOut.click(function(){
          var konfirmasiKeluar = confirm("Anda yakin ingin keluar?");
          if(konfirmasiKeluar == true){
            alert("Terima kasih telah menggunakan ApheresisApps. ");
            localStorage.removeItem("emailId");
            window.location.assign('../index.html');
          }else{
            
          }
          
        });
        
        tblRequestDonor.click(function(){
          eventTombol("Request donor");
          var loading = "<div class='progress'><div class='indeterminate'></div></div>";
           $('#loading').html(loading);
            $('#judulApps').html("Request Donor - Apheresis Apps");
            $('#divUtama').load('requestDonor.php');
            $('#loading').html("");
           $('.button-collapse').sideNav('hide');
        });
           
          btnDasborFloat.click(function(){
            eventTombol("Dasbor Float");
            var loading = "<div class='progress'><div class='indeterminate'></div></div>";
            $('#loading').html(loading);
            $('#judulApps').html("Beranda - Apheresis Apps");
            $('#divUtama').load('berandaPendonor.php');
            $('#loading').html("");
          });
  
          btnInfoFloat.click(function(){
            eventTombol("Info Float");
            var loading = "<div class='progress'><div class='indeterminate'></div></div>";
            $('#loading').html(loading);
            $('#judulApps').html("Tentang Aplikasi - Apheresis Apps");
            $('#divUtama').load('tentangApps.php');
            $('#loading').html("");            
          }); 
  
  
  $('#tentangSideNav').click(function(){
            var loading = "<div class='progress'><div class='indeterminate'></div></div>";
            $('#loading').html(loading);
            $('#judulApps').html("Tentang Aplikasi - Apheresis Apps");
            $('#divUtama').load('tentangApps.php');
            $('#loading').html("");
    $('.button-collapse').sideNav('hide');
            
          });
  
  
  
  
          
  
          
});