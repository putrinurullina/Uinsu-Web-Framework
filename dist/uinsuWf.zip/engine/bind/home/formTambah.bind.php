<!DOCTYPE html>
<html>
<head>
<title><?=SITENAME; ?></title>
</head>
<form action="<?=HOMEBASE; ?>home/proTambahData" method='POST'>
Nim <input type="number" name='txtNim'><br/>
Nama <input type="text" name='txtNama'><br/>
Email <input type="text" name='txtEmail'><br/>
<input type="submit" value="Daftar">
</form>
</html>