

<ul>
<li><?=$data['mhs']['nama']; ?></li>
<li><?=$data['mhs']['nim']; ?></li>
<li><?=$data['mhs']['email']; ?></li>
</ul>

