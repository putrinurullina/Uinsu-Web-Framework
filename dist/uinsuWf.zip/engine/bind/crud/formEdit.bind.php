<?php
$mhs = $data['mhsDetail'];
echo $mhs['jurusan'];
?>