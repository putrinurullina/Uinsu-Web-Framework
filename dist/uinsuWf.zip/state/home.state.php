class home{

public function __construct(){
$db = new db;
}

public function getMahasiswa()
{

}

public function getMahasiswaAll()
{

}

}
