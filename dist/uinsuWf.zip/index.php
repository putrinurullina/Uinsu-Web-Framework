<?php
//welcome to Uinsu Web Framework
//Framework ini masih dalam pengembangan
//Berbagai fungsi akan ditambahkan untuk memperlengkap web framework ini
//Developer : HaxorsProgrammingClub
//Pengembangan inti Framework ini mengikuti tutorial dari bapak shandika galih selaku pemilik channel yotube "Web Programming Unpas"
//Tim Pengembang Uinsu Web Framework
//Pembina -> Muhammad Ikhsan, ST. M.Kom
//Core Project -> Aditia Darma Nasution
//Ecosystem -> Adam Falizufa Sagara
//Tester -> Abdillah


require_once 'engine/init.php';

$props = new Props;
