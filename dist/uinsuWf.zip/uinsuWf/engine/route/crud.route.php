<?php

class crud extends Route{


public function index()
{
	$this -> bind('/crud/default');

}

public function tampilMahasiswa()
{
	$data['mhs'] = $this -> state('crudSt') -> mhsDataAll();
	$this -> bind('/crud/tampilData',$data);
}

public function editMahasiswa()
{
	
}


}